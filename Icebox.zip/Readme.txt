Introduction
Icebox is an implementation of Maxis SimCity simulation engine named GlassBox presented during 2012 GDC conference. This project is not an affiliated project of the conference or Maxis.  Simply this is a port from a C#/Unity project to C# only project example.   The original project has aged more than 8 years.

REF:
https://github.com/federicodangelo/MultiAgentSimulation


Screenshot




In this screenshot:

    In pink: houses (static).
    In cyan: factories (static).
    In yellow/orange: people/workers


Notes:
Certain class and functions and procedures have been renamed this helps avoid confusion with the original code.


Future
Include rules based editor and engine