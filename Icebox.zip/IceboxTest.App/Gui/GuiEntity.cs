﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IceboxTest.Gui
{
     public abstract class GuiEntity
     {

          public abstract void Render(Graphics g);

     }
}
