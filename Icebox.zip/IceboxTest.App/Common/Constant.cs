﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace IceboxTest.Common
{

     public sealed class Constant
     {
          internal const int FormOffset = 32;
     }
}
