using System;
using System.Collections.Generic;


namespace Icebox
{
	public class SimResource
	{
		public string id;
	}
}