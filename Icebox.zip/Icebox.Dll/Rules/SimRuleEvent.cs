using System;


namespace Icebox
{
	public class SimRuleEvent
	{
		public string key;
		public string parameter;
	}
}

