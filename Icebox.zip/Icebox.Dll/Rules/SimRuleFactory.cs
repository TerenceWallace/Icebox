using System;


namespace Icebox
{
	public class SimRuleFactory
	{

	}
}

