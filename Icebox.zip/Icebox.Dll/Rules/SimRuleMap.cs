using System;


namespace Icebox
{
	public class SimRuleMap : SimRule
	{
		public bool randomTiles = false;
		public int randomTilesPercent = 10;
	}

}
