using System;


namespace Icebox
{
	public class SimulationListenerNull : ISimulationListener
	{
		public void OnBoxAdded(SimBox box)
		{
		}

		public void OnBoxRemoved(SimBox box)
		{
		}
	}

}
