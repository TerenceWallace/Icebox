using System;

namespace Icebox
{
	public class SimSegmentType
	{
		public string id;

		public int color;
	}

}
