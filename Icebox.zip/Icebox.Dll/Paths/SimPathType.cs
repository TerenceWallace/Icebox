using System;

namespace Icebox
{
	public class SimPathType
	{
		public string id;

		public int color;
	}

}
