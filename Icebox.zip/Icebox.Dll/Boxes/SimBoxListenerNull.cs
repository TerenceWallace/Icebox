using System;

namespace Icebox
{
	public class SimBoxListenerNull : ISimBoxListener
	{
		public void OnMapAdded(SimMap map)
		{
		}

		public void OnMapRemoved(SimMap map)
		{
		}

		public void OnPathAdded(SimPath path)
		{
		}

		public void OnPathRemoved(SimPath path)
		{
		}

		public void OnUnitAdded(SimUnit unit)
		{
		}

		public void OnUnitRemoved(SimUnit unit)
		{
		}

		public void OnAgentAdded(SimAgent agent)
		{
		}

		public void OnAgentRemoved(SimAgent agent)
		{
		}
	}
}

