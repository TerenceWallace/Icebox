using System;

namespace Icebox
{
	public class SimMapListenerNull : ISimMapListener
	{
		public void OnMapModified(SimMap map, int x, int y, int val)
		{
		}
	}

}
