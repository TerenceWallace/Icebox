
namespace Icebox
{

     public class SimMapType
     {
          public string id;

          public int color;

          public int capacity;

          public SimRuleMap[] rules;
     }

}
