using System;

namespace Icebox
{
	public class SimAgentType
	{
		public string id;

		public int color;

		public float speed;
	}
}

